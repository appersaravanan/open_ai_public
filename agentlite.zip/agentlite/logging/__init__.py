from agentlite.logging.terminal_logger import AgentLogger

DefaultLogger = AgentLogger()
