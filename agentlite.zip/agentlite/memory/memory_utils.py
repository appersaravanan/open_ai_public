MEMORY_TASK_KEY = "task"  # reference TaskPackage
MEMORY_ACT_OBS_KEY = "act_obs"  # reference (action,obs) chain
