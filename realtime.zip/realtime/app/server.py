import asyncio
import base64
import json
import logging
import struct
import os
import sys
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING, Any

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi import Body
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from typing_extensions import assert_never

# Ensure we import the local SDK from ../../../../src instead of any installed copy
_SRC_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", "src"))
if _SRC_PATH not in sys.path:
    sys.path.insert(0, _SRC_PATH)

from agents.realtime import RealtimeRunner, RealtimeSession, RealtimeSessionEvent
from agents.realtime.config import RealtimeUserInputMessage
from agents.realtime.items import RealtimeItem
from agents.realtime.model import RealtimeModelConfig
from agents.realtime.model_inputs import (
    RealtimeModelSendRawMessage,
    RealtimeModelSendSessionUpdate,
)

# PDF forms helper (optional endpoint for account onboarding)
_FORMS_AGENT_PATH = os.path.abspath(
    os.path.join(_SRC_PATH, "agents", "realtime", "forms-agent", "forms-filling-agent.py")
)
_forms_mod = None
if os.path.exists(_FORMS_AGENT_PATH):
    try:
        import importlib.util

        spec = importlib.util.spec_from_file_location("forms_filling_agent", _FORMS_AGENT_PATH)
        if spec and spec.loader:
            _forms_mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(_forms_mod)
    except Exception:
        _forms_mod = None

# Import TwilioHandler class - handle both module and package use cases
if TYPE_CHECKING:
    # For type checking, use the relative import
    from .agent import get_starting_agent
else:
    # At runtime, try both import styles
    try:    
        # Try relative import first (when used as a package)
        from .agent import get_starting_agent
    except ImportError:
        # Fall back to direct import (when run as a script)
        from agent import get_starting_agent


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class RealtimeWebSocketManager:
    def __init__(self):
        self.active_sessions: dict[str, RealtimeSession] = {}
        self.session_contexts: dict[str, Any] = {}
        self.websockets: dict[str, WebSocket] = {}
        self.event_tasks: dict[str, asyncio.Task] = {}

    async def connect(self, websocket: WebSocket, session_id: str, voice: str | None = None):
        await websocket.accept()
        self.websockets[session_id] = websocket

        agent = get_starting_agent()
        runner = RealtimeRunner(agent)
        # If you want to customize the runner behavior, you can pass options:
        # runner_config = RealtimeRunConfig(async_tool_calls=False)
        # runner = RealtimeRunner(agent, config=runner_config)
        # Use voice from UI if provided (fallback to current default)
        logger.info(f"Realtime connect: session %s, voice=%s", session_id, voice)
        selected_voice = voice or "verse"
        logger.info(f"Realtime connect: session %s, selected_voice=%s", session_id, selected_voice)
        model_config: RealtimeModelConfig = {
            "initial_model_settings": {
                "turn_detection": {
                    "type": "server_vad",
                    "prefix_padding_ms": 300,
                    "silence_duration_ms": 500,
                    "interrupt_response": True,
                    "create_response": True,
                },
                "voice": selected_voice,  # set by UI dropdown if provided
                "output_audio_format": {"type": "audio/pcm", "rate": 24000},
            },
        }
        import ssl
        ssl._create_default_https_context = ssl._create_unverified_context
        session_context = await runner.run(model_config=model_config)
        session = await session_context.__aenter__()
       

        self.active_sessions[session_id] = session
        self.session_contexts[session_id] = session_context

        # Start event processing task and keep a handle for clean cancellation
        task = asyncio.create_task(self._process_events(session_id))
        self.event_tasks[session_id] = task
        # Acknowledge to the client which voice was applied at session start
        try:
            await websocket.send_text(
                json.dumps({"type": "client_info", "info": "voice_applied", "voice": selected_voice})
            )
        except Exception:
            pass

    async def disconnect(self, session_id: str):
        # Cancel background event task first to stop iteration on the session
        task = self.event_tasks.pop(session_id, None)
        if task is not None:
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
            except Exception:
                pass

        # Then, close the session context cleanly
        if session_id in self.session_contexts:
            try:
                await self.session_contexts[session_id].__aexit__(None, None, None)
            except Exception:
                pass
            del self.session_contexts[session_id]
        if session_id in self.active_sessions:
            del self.active_sessions[session_id]
        if session_id in self.websockets:
            del self.websockets[session_id]

    async def send_audio(self, session_id: str, audio_bytes: bytes):
        if session_id in self.active_sessions:
            await self.active_sessions[session_id].send_audio(audio_bytes)

    async def send_client_event(self, session_id: str, event: dict[str, Any]):
        """Send a raw client event to the underlying realtime model."""
        session = self.active_sessions.get(session_id)
        if not session:
            return
        await session.model.send_event(
            RealtimeModelSendRawMessage(
                message={
                    "type": event["type"],
                    "other_data": {k: v for k, v in event.items() if k != "type"},
                }
            )
        )
    async def update_voice(self, session_id: str, voice: str) -> None:
        """Update the assistant voice on an established session via session.update."""
        session = self.active_sessions.get(session_id)
        websocket = self.websockets.get(session_id)
        if not session:
            logger.warning("update_voice ignored; no active session %s", session_id)
            return
        try:
            logger.info("Session %s: interrupting current response before voice update", session_id)
            await session.interrupt()

            logger.info("Session %s: sending session.update voice=%r", session_id, voice)
            await session.model.send_event(
                RealtimeModelSendSessionUpdate(
                    session_settings={
                        "voice": voice,
                        "output_audio_format": {"type": "audio/pcm", "rate": 24000},
                    }
                )
            )
            logger.info("Session %s: session.update dispatched (voice=%r)", session_id, voice)

            if websocket:
                await websocket.send_text(
                    json.dumps({"type": "client_info", "info": "voice_applied", "voice": voice})
                )
        except Exception as e:
            logger.exception("update_voice failed for %s: %s", session_id, e)
            if websocket:
                await websocket.send_text(
                    json.dumps({"type": "error", "error": f"voice_update_failed: {e}"})
                )

    async def send_user_message(self, session_id: str, message: RealtimeUserInputMessage):
        """Send a structured user message via the higher-level API (supports input_image)."""
        session = self.active_sessions.get(session_id)
        if not session:
            return
        await session.send_message(message)  # delegates to RealtimeModelSendUserInput path

    async def send_ui_event(self, session_id: str, event: dict[str, Any]) -> None:
        """Send an out-of-band UI event (not a model event) to the browser."""
        websocket = self.websockets.get(session_id)
        if not websocket:
            return
        await websocket.send_text(json.dumps(event))

    async def broadcast_ui_event(self, event: dict[str, Any]) -> None:
        """Broadcast an out-of-band UI event to all connected sessions."""
        dead: list[str] = []
        for sid, ws in list(self.websockets.items()):
            try:
                await ws.send_text(json.dumps(event))
            except Exception:
                dead.append(sid)
        for sid in dead:
            try:
                await self.disconnect(sid)
            except Exception:
                pass

    async def interrupt(self, session_id: str) -> None:
        """Interrupt current model playback/response for a session."""
        session = self.active_sessions.get(session_id)
        if not session:
            return
        await session.interrupt()

    async def _process_events(self, session_id: str):
        try:
            session = self.active_sessions.get(session_id)
            websocket = self.websockets.get(session_id)
            if not session or not websocket:
                return

            async for event in session:
                try:
                    event_data = await self._serialize_event(event)
                    await websocket.send_text(json.dumps(event_data))
                except Exception:
                    # If the websocket is closed or sending fails, break out and let disconnect clean up
                    break
        except asyncio.CancelledError:
            # Normal during disconnect
            return
        except Exception as e:
            logger.error(f"Error processing events for session {session_id}: {e}")

    def _sanitize_history_item(self, item: RealtimeItem) -> dict[str, Any]:
        """Remove large binary payloads from history items while keeping transcripts."""
        item_dict = item.model_dump()
        content = item_dict.get("content")
        if isinstance(content, list):
            sanitized_content: list[Any] = []
            for part in content:
                if isinstance(part, dict):
                    sanitized_part = part.copy()
                    if sanitized_part.get("type") in {"audio", "input_audio"}:
                        sanitized_part.pop("audio", None)
                    sanitized_content.append(sanitized_part)
                    
                else:
                    sanitized_content.append(part)
            item_dict["content"] = sanitized_content
            #print("sanitized_content",sanitized_content)
        return item_dict

    async def _serialize_event(self, event: RealtimeSessionEvent) -> dict[str, Any]:
        base_event: dict[str, Any] = {
            "type": event.type,
        }

        if event.type == "agent_start":
            base_event["agent"] = event.agent.name
        elif event.type == "agent_end":
            base_event["agent"] = event.agent.name
            print("agent_end",event.agent.name)
        elif event.type == "handoff":
            base_event["from"] = event.from_agent.name
            base_event["to"] = event.to_agent.name
        elif event.type == "tool_start":
            base_event["tool"] = event.tool.name
        elif event.type == "tool_end":
            base_event["tool"] = event.tool.name
            base_event["output"] = str(event.output)
        elif event.type == "audio":
            base_event["audio"] = base64.b64encode(event.audio.data).decode("utf-8")
        elif event.type == "audio_interrupted":
            pass
        elif event.type == "audio_end":
            pass
        elif event.type == "history_updated":
            base_event["history"] = [self._sanitize_history_item(item) for item in event.history]
        elif event.type == "history_added":
            # Provide the added item so the UI can render incrementally.
            try:
                base_event["item"] = self._sanitize_history_item(event.item)
            except Exception:
                base_event["item"] = None
        elif event.type == "guardrail_tripped":
            base_event["guardrail_results"] = [
                {"name": result.guardrail.name} for result in event.guardrail_results
            ]
        elif event.type == "raw_model_event":
            base_event["raw_model_event"] = {
                "type": event.data.type,
            }
        elif event.type == "error":
            base_event["error"] = str(event.error) if hasattr(event, "error") else "Unknown error"
        elif event.type == "input_audio_timeout_triggered":
            pass
        else:
            assert_never(event)

        return base_event


manager = RealtimeWebSocketManager()


@asynccontextmanager
async def lifespan(app: FastAPI):
    try:
        yield
    finally:
        # Best-effort cleanup of all active sessions/tasks on shutdown
        ids = list(manager.session_contexts.keys())
        for sid in ids:
            try:
                await manager.disconnect(sid)
            except Exception:
                pass


app = FastAPI(lifespan=lifespan)


@app.post("/api/onboarding/update")
async def onboarding_update(payload: dict[str, Any] = Body(...)):
    """Receive extracted onboarding fields and push them to the UI.

    Request JSON:
      {
        "session_id": "session_..." (optional; if omitted broadcasts to all),
        "fields": {"FullName": "...", ...},
        "source": "agent"|"user"|"assistant" (optional)
      }
    """
    fields = payload.get("fields")
    if not isinstance(fields, dict):
        return {"ok": False, "error": "fields must be an object"}

    session_id = payload.get("session_id")
    source = payload.get("source")
    event = {
        "type": "onboarding_update",
        "fields": fields,
        "source": source or "agent",
    }

    try:
        if isinstance(session_id, str) and session_id:
            await manager.send_ui_event(session_id, event)
        else:
            await manager.broadcast_ui_event(event)
    except Exception as e:
        return {"ok": False, "error": str(e)}

    return {"ok": True}

# Ensure local output directory exists for generated PDFs (mounted below)
_GENERATED_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "generated"))
os.makedirs(_GENERATED_DIR, exist_ok=True)


@app.post("/api/forms/account-onboarding")
async def generate_account_onboarding_pdf(
    payload: dict[str, Any] = Body(...),
):
    """Generate a filled onboarding PDF from provided form fields.

    Request JSON:
      {
        "fields": {"FullName": "...", ...},
        "template_pdf_path": "/abs/or/relative/path/to/template.pdf" (optional)
      }
    """
    fields = payload.get("fields")
    if not isinstance(fields, dict):
        return {"ok": False, "error": "fields must be an object"}

    template_pdf_path = payload.get("template_pdf_path")
    if template_pdf_path is None:
        # Default: look for a template under app/forms
        template_pdf_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "forms", "account_onboarding_template.pdf"))
    else:
        template_pdf_path = os.path.abspath(str(template_pdf_path))

    out_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "generated"))
    os.makedirs(out_dir, exist_ok=True)
    output_pdf_path = os.path.join(out_dir, "account_onboarding_filled.pdf")

    if _forms_mod is None or not hasattr(_forms_mod, "fill_pdf_form"):
        return {
            "ok": False,
            "error": "Forms helper not available (could not import forms-filling-agent.py)",
        }

    try:
        result = _forms_mod.fill_pdf_form(template_pdf_path, output_pdf_path, fields)
        # fill_pdf_form returns a string; either a path or an error message
        if isinstance(result, str) and result.startswith("Failed"):
            return {"ok": False, "error": result}
        if isinstance(result, str) and result.startswith("Missing dependency"):
            return {"ok": False, "error": result}
        if isinstance(result, str) and result.startswith("Template PDF not found"):
            return {"ok": False, "error": result}
        if not os.path.exists(output_pdf_path):
            return {"ok": False, "error": f"PDF not generated: {result}"}
    except Exception as e:
        return {"ok": False, "error": f"Failed to generate PDF: {e}"}

    return {
        "ok": True,
        "output_pdf_path": output_pdf_path,
        "download_url": "/generated/account_onboarding_filled.pdf",
    }


@app.websocket("/ws/{session_id}")
async def websocket_endpoint(websocket: WebSocket, session_id: str):
    # Read optional voice from query string (set by the UI dropdown)
    try:
       raw_qs = websocket.scope.get("query_string", b"").decode(errors="ignore")
       logger.info("WS %s query: %s", session_id, raw_qs)

       voice = websocket.query_params.get("voice") or None
       logger.info("WS %s voice param=%r", session_id, voice)

    except Exception:
        voice = None
    await manager.connect(websocket, session_id, voice=voice)
    image_buffers: dict[str, dict[str, Any]] = {}
    try:
        while True:
            data = await websocket.receive_text()
            message = json.loads(data)

            if message["type"] == "audio":
                # Convert int16 array to bytes
                int16_data = message["data"]
                audio_bytes = struct.pack(f"{len(int16_data)}h", *int16_data)
                await manager.send_audio(session_id, audio_bytes)
            elif message["type"] == "image":
                logger.info("Received image message from client (session %s).", session_id)
                # Build a conversation.item.create with input_image (and optional input_text)
                data_url = message.get("data_url")
                prompt_text = message.get("text") or "Please describe this image."
                if data_url:
                    logger.info(
                        "Forwarding image (structured message) to Realtime API (len=%d).",
                        len(data_url),
                    )
                    user_msg: RealtimeUserInputMessage = {
                        "type": "message",
                        "role": "user",
                        "content": (
                            [
                                {"type": "input_image", "image_url": data_url, "detail": "high"},
                                {"type": "input_text", "text": prompt_text},
                            ]
                            if prompt_text
                            else [{"type": "input_image", "image_url": data_url, "detail": "high"}]
                        ),
                    }
                    await manager.send_user_message(session_id, user_msg)
                    # Acknowledge to client UI
                    await websocket.send_text(
                        json.dumps(
                            {
                                "type": "client_info",
                                "info": "image_enqueued",
                                "size": len(data_url),
                            }
                        )
                    )
                else:
                    await websocket.send_text(
                        json.dumps(
                            {
                                "type": "error",
                                "error": "No data_url for image message.",
                            }
                        )
                    )
            elif message["type"] == "commit_audio":
                # Force close the current input audio turn
                await manager.send_client_event(session_id, {"type": "input_audio_buffer.commit"})
            elif message["type"] == "image_start":
                img_id = str(message.get("id"))
                image_buffers[img_id] = {
                    "text": message.get("text") or "Please describe this image.",
                    "chunks": [],
                }
                await websocket.send_text(
                    json.dumps({"type": "client_info", "info": "image_start_ack", "id": img_id})
                )
            elif message["type"] == "image_chunk":
                img_id = str(message.get("id"))
                chunk = message.get("chunk", "")
                if img_id in image_buffers:
                    image_buffers[img_id]["chunks"].append(chunk)
                    if len(image_buffers[img_id]["chunks"]) % 10 == 0:
                        await websocket.send_text(
                            json.dumps(
                                {
                                    "type": "client_info",
                                    "info": "image_chunk_ack",
                                    "id": img_id,
                                    "count": len(image_buffers[img_id]["chunks"]),
                                }
                            )
                        )
            elif message["type"] == "image_end":
                img_id = str(message.get("id"))
                buf = image_buffers.pop(img_id, None)
                if buf is None:
                    await websocket.send_text(
                        json.dumps({"type": "error", "error": "Unknown image id for image_end."})
                    )
                else:
                    data_url = "".join(buf["chunks"]) if buf["chunks"] else None
                    prompt_text = buf["text"]
                    if data_url:
                        logger.info(
                            "Forwarding chunked image (structured message) to Realtime API (len=%d).",
                            len(data_url),
                        )
                        user_msg2: RealtimeUserInputMessage = {
                            "type": "message",
                            "role": "user",
                            "content": (
                                [
                                    {
                                        "type": "input_image",
                                        "image_url": data_url,
                                        "detail": "high",
                                    },
                                    {"type": "input_text", "text": prompt_text},
                                ]
                                if prompt_text
                                else [
                                    {"type": "input_image", "image_url": data_url, "detail": "high"}
                                ]
                            ),
                        }
                        await manager.send_user_message(session_id, user_msg2)
                        await websocket.send_text(
                            json.dumps(
                                {
                                    "type": "client_info",
                                    "info": "image_enqueued",
                                    "id": img_id,
                                    "size": len(data_url),
                                }
                            )
                        )
                    else:
                        await websocket.send_text(
                            json.dumps({"type": "error", "error": "Empty image."})
                        )
            elif message["type"] == "interrupt":
                await manager.interrupt(session_id)
            elif message["type"] == "update_voice":
                new_voice = message.get("voice")
                logger.info("WS %s update_voice=%r", session_id, new_voice)
                if isinstance(new_voice, str) and new_voice:
                    await manager.update_voice(session_id, new_voice)
                else:
                    await websocket.send_text(
                        json.dumps({"type": "error", "error": "Invalid or missing voice"})
                    )

    except WebSocketDisconnect:
        await manager.disconnect(session_id)


app.mount("/", StaticFiles(directory="static", html=True), name="static")
app.mount(
    "/generated",
    StaticFiles(directory=_GENERATED_DIR, html=False),
    name="generated",
)


@app.get("/")
async def read_index():
    return FileResponse("static/index.html")


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8000,
        # Increased WebSocket frame size to comfortably handle image data URLs.
        ws_max_size=16 * 1024 * 1024,
    )
