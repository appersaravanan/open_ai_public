# Account Onboarding PDF Template

The UI panel **Account Onboarding** posts the entered values to:

- `POST /api/forms/account-onboarding`

That endpoint fills an AcroForm PDF template using the existing `fill_pdf_form` helper.

## Add your PDF template

Place your AcroForm template at:

- `examples/realtime/app/forms/account_onboarding_template.pdf`

Your PDF must contain AcroForm field names that match the keys the UI sends.

## Field mapping

The current UI sends these keys (you can change them in `static/app.js` -> `getOnboardingFields()`):

- `FullName`
- `DateOfBirth`
- `Email`
- `Phone`
- `AddressLine1`
- `AddressLine2`
- `City`
- `State`
- `PostalCode`
- `Country`
- `AccountType`
- `KYCLevel`

## Output

Generated PDFs are written to:

- `examples/realtime/app/generated/account_onboarding_filled.pdf`

and served at:

- `/generated/account_onboarding_filled.pdf`

## Notes

- The PDF filling tool requires `pypdf`:

```bash
pip install pypdf
```
