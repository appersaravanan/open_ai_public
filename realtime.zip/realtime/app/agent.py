import asyncio
import json
import os
import traceback

from agents import function_tool,input_guardrail
from agents.agent import Agent
from agents.agent_output import AgentOutputSchema
from agents.extensions.handoff_prompt import RECOMMENDED_PROMPT_PREFIX
from agents.guardrail import GuardrailFunctionOutput, output_guardrail
from agents.items import TResponseInputItem
from agents.realtime import RealtimeAgent, realtime_handoff
from agents.run import Runner
from agents.run_context import RunContextWrapper
from pydantic import BaseModel
from open_browser import open_app, open_app_async
import os
os.environ["OPENAI_API_KEY"] = ""

"""
When running the UI example locally, you can edit this file to change the setup. THe server
will use the agent returned from get_starting_agent() as the starting agent."""

### TOOLS
def disable_openai_tracing():
    # Defensive: unset known env vars
    for var in [
        "OPENAI_TRACING",
        "OPENAI_TRACING_ENDPOINT",
        "OPENAI_TRACE_ID",
        "OPENAI_TRACES_URL",
    ]:
        if var in os.environ:
            os.environ.pop(var)
    # Optional flag some clients honor
    os.environ["OPENAI_DISABLE_TRACING"] = "1"

disable_openai_tracing()

class MessageOutput(BaseModel): # (1)!
    response: str
class OnboardingFields(BaseModel):
    FullName: str | None = None
    DateOfBirth: str | None = None
    Email: str | None = None
    Phone: str | None = None
    AddressLine1: str | None = None
    AddressLine2: str | None = None
    City: str | None = None
    State: str | None = None
    PostalCode: str | None = None
    Country: str | None = None
    AccountType: str | None = None
    KYCLevel: str | None = None

# @function_tool
async def push_onboarding_fields(fields: OnboardingFields) -> str:
    """Push extracted onboarding fields to the UI to live-fill the form.

    This implementation broadcasts to all connected sessions (fine for single-browser usage).
    """
    try:
        print("push_onboarding_fields called with:", fields)
        import urllib.request

        payload_fields = {k: v for k, v in fields.model_dump().items() if v not in (None, "")}
        if not payload_fields:
            return "ok"

        payload = json.dumps({"fields": payload_fields, "source": "agent"}).encode("utf-8")
        req = urllib.request.Request(
            "http://localhost:8000/api/onboarding/update",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            _ = resp.read().decode("utf-8", errors="ignore")
        return "ok"
    except Exception as e:
        return f"failed: {e}"



OnboardingFieldsSchema = AgentOutputSchema(OnboardingFields, strict_json_schema=False)


onboarding_listener_agent = Agent(
    name="Onboarding Listener",
    handoff_description="Extracts account onboarding fields from conversation and updates the onboarding form UI.",
    instructions=f"""{RECOMMENDED_PROMPT_PREFIX}
You listen to both user and assistant messages.
Extract ONLY the onboarding fields that are explicitly present (do not guess).

When you learn any fields, immediately call `push_onboarding_fields(fields=...)`.
Send only the keys you are confident about; omit unknowns.
The UI will only fill empty fields (non-destructive).
""",
    #tools=[push_onboarding_fields],
    output_type=OnboardingFieldsSchema,
)


@output_guardrail
async def onboarding_extractor_guardrail(
    ctx: RunContextWrapper[None], agent: Agent, output: MessageOutput
) -> GuardrailFunctionOutput:
    """Extract onboarding fields from the assistant response and push updates to the UI.

    Using an output guardrail makes this run on every assistant turn without changing routing.
    """
    try:
        text = output.response if hasattr(output, "response") else str(output)
        print("onboarding_extractor_guardrail input:", text)
        rr = await Runner.run(onboarding_listener_agent, text, context=ctx.context)
        extracted = rr.final_output
        print("onboarding_extractor_guardrail extracted:", extracted)
        if isinstance(extracted, OnboardingFields):
            await push_onboarding_fields(extracted)
    except Exception as e:
       
        print(traceback.format_exc())
        print("onboarding_extractor_guardrail error:", e)

    return GuardrailFunctionOutput(output_info=None, tripwire_triggered=False)


@function_tool
async def wire_transfer_status(account_number: str, amount: str) -> str:
    """
    provide account wire transfer status.

    Args:
        account_number: The account_number  for the wire transfer.
        amount: the amount they transfered
    """
    print("wire_transfer_status",account_number)
    return f"Account {account_number} that has outgoing wire tranfer with amount {amount}. ETA for transfer is 4 PM ET"

@function_tool
async def lock_the_lost_card(account_number: str, client_name: str,case_type:str) -> str:
    """
    lock the lost card.

    Args:
        account_number: The account_number to lock the lost card.
        client_name: the client name
        case_type: type of case to open
       
    """
    print("lock_the_lost_card", account_number)
    return f"Locked card for account {account_number} with client {client_name} "



@function_tool
async def open_privacy_incident_application(account_number: str, client_name: str,case_type:str) -> str:
    """
    this method will be used if there is any privacy informaion lost.
      privacy incident application.

    Args:
        account_number: The account_number to open privacy incident application.
        client_name: the client name
        case_type: type of case to open
       
    """
    print("open_privacy_incident_application", account_number)
    return f"Privacy incident application opened for account {account_number} with client {client_name} and case type {case_type}."


wire_status = RealtimeAgent(
    name="Account wire transfer status",
    handoff_description="A helpful agent that can update about Account wire transfer status",
    instructions=f"""{RECOMMENDED_PROMPT_PREFIX}
    You are a Account wire transfer status. If you are speaking to a customer, you probably were transferred to from the triage agent.
    Use the following routine to support the customer.
    # Routine
    1. Ask for the account number.
    2. Ask for amount transfered .
    3. provide answer about the account transfers.
    If the customer asks a question that is not related to the routine, transfer back to the triage agent. """,
    tools=[wire_transfer_status],
)


class PrivacyOutput(BaseModel):
    is_privacy_incident_required: bool
    reasoning: str
PrivacyOutputSchema = AgentOutputSchema(
    PrivacyOutput,
    
    strict_json_schema=False,  # disable strict to avoid schema error
)
guardrail_agent = Agent( # (1)!
    name="privacy information  loss ",
    instructions=("you are going to listen to customer conversation and open a ticket if the customer sentiment is"
    "towards privacy information  loss such as credit card,ssn etc."
    "Example : 'customer lost credit card' , 'customer ssn lost'  - privacy info lost."),
      
    output_type=PrivacyOutputSchema,
)

@output_guardrail
async def privacy_guardrail( # (2)!
    ctx: RunContextWrapper[None], agent: Agent, output: MessageOutput
) -> GuardrailFunctionOutput:
    print("privacy_guardrail input:",output)
    try:
        result = await Runner.run(guardrail_agent, output, context=ctx.context)
        print("privacy_guardrail inner result:",result.final_output)
        if  isinstance(result.final_output, PrivacyOutput) and result.final_output.is_privacy_incident_required:
            print("Privacy incident required:", result.final_output.reasoning)
            asyncio.create_task(open_app_async(url="http://localhost:4200", stay_seconds=36000)) # Simulate opening the privacy incident application
    except Exception as e:
        print("privacy_guardrail error:", e)
        result = PrivacyOutput(is_privacy_incident_required=False, reasoning=str(e))
    print("privacy_guardrail result:",result)

    return GuardrailFunctionOutput(
        output_info=result, # (3)!
        tripwire_triggered=False,
    )
sentiment_analyze_agent = RealtimeAgent(
    name="Sentiment Analysis Agent",
    handoff_description="A helpful agent that can analyze sentiment.",
    instructions=f"""{RECOMMENDED_PROMPT_PREFIX}
    You are a Sentiment Analysis Agent. you are going to listen to customer conversation and open a ticket if the customer sentiment is towards privacy information 
    loss such as credit card,ssn etc. use the tools to create a ticket.
      you probably were transferred to from the triage agent.""",
    tools=[open_privacy_incident_application],
)
lost_card_agent = RealtimeAgent(
    name="Lost Card processor Agent",
    handoff_description="A helpful agent that can process lost cards.",
    instructions=f"""{RECOMMENDED_PROMPT_PREFIX}
    You are a Lost Card processor Agent. 
    f you are speaking to a customer, you probably were transferred to from the triage agent.
    Use the following routine to support the customer.
    # Routine
    1. Ask for customer name .
    2. Ask for the account number OR credit card 4 digits.
    3. Ask for the year of birth.
    If the customer asks a question that is not related to the routine, transfer back to the sentiment analyze agent.""",
    tools=[lock_the_lost_card],
    output_guardrails=[ privacy_guardrail],
    
    
)


triage_agent = RealtimeAgent(
    name="Triage Agent",
    handoff_description="A triage agent that can delegate a customer's request to the appropriate agent.",
    instructions=(
        f"{RECOMMENDED_PROMPT_PREFIX} "
        "You are a helpful triaging agent."
        " You can use your tools to delegate questions to other"
        " appropriate agents. "
    ),
    output_guardrails=[onboarding_extractor_guardrail],
    handoffs=[wire_status,lost_card_agent,],
)


wire_status.handoffs.append(triage_agent)
lost_card_agent.handoffs.append(triage_agent)

def get_starting_agent() -> RealtimeAgent:
    return triage_agent

