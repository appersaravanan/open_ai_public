from __future__ import annotations
import asyncio, time
from typing import Optional
from playwright.async_api import async_playwright

APP_URL = "http://localhost:8000"

async def wait_for(url: str, timeout: int = 20) -> bool:
    import aiohttp
    start = time.time()
    async with aiohttp.ClientSession() as session:
        while time.time() - start < timeout:
            try:
                async with session.get(url) as _:
                    return True
            except Exception:
                await asyncio.sleep(0.5)
    return False
async def open_app_async(
    url: str = APP_URL,
    headless: bool = False,
    stay_seconds: Optional[int] = 3600
) -> None:
    if not await wait_for(url):
        print(f"Server not reachable at {url} (timeout). Start server.py first.")
        return
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=headless)
        page = await browser.new_page()
        await page.goto(url)
        print(f"Opened {url}. Press Ctrl+C to exit (stay_seconds={stay_seconds}).")
        try:
            if stay_seconds is None:          # None => wait indefinitely
                while True:
                    await asyncio.sleep(5)
            elif stay_seconds > 0:
                await page.wait_for_timeout(stay_seconds * 1000)
            else:
                # 0 or negative → keep 30s default
                await page.wait_for_timeout(30_000)
        except KeyboardInterrupt:
            print("Closing browser...")
        finally:
            await browser.close()

def open_app(url: str = APP_URL, stay_seconds: int | None = 3600):
    # Sync wrapper (avoid calling inside an existing event loop)
    asyncio.run(open_app_async(url=url, stay_seconds=stay_seconds))